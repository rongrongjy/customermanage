create
    definer = root@localhost function fun3(num1 float, num2 float) returns float
begin
declare sum float default 0;
set sum=num1+num2;
return sum;
end;

