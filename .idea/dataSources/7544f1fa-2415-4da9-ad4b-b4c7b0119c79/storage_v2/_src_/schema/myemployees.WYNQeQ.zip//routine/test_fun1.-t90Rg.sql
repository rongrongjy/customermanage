create
    definer = root@localhost function test_fun1(num1 float, num2 float) returns float
BEGIN
DECLARE SUM FLOAT DEFAULT 0;
SET SUM=num1+num2;
RETURN SUM;
END;

