create
    definer = root@localhost procedure test_if_pro(IN sal double)
begin
if sal<2000 then delete from employees where employees.salary=sal;
elseif sal>=2000 and sal<5000 then update employees set salary=salary+1000
where employees.salary=sal;
else update employees set salary=salary+500 where employees.salary=sal;
end if;

end;

