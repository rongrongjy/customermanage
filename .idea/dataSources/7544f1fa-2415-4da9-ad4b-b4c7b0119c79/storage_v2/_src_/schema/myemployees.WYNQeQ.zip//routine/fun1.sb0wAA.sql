create
    definer = root@localhost function fun1() returns int
begin
declare c int default 0;
select count(*) into c
from employees;
return c;
end;

